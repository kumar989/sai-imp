export class User {
   fullname:String;
   email:String;
   password:String;
   repeatpassword:String;
}